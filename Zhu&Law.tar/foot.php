        </div>
		<div class="footer">
                <br/><br/>
                &copy; <i>Copyright 2017, Lingyang Zhu, Derek Law</i>
                <br/>
                This site is part of a CSU <a href="http://www.cs.colostate.edu/~ct310">CT 310</a> Course Project.
		<br/>
                </div>
	
	</body>
</html>
